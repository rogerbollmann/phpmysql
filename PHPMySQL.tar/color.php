<?php

echo "<a href=\"color.php?colour=Red\">Background Red<a/><br>";
echo "<a href=\"color.php?colour=Blue\">Background Blue<a/><br>";
echo "<a href=\"color.php?colour=Green\">Background Green<a/><br>";
echo "<a href=\"color.php\">Back<a/>";

if ($_GET[colour]=="Red") setBackgroundColour("Red");
if ($_GET[colour]=="Blue") setBackgroundColour("Blue");
if ($_GET[colour]=="Green") setBackgroundColour("Green");

function setBackgroundColour($setColor){
echo  "<body style=\"background-color: {$setColor}; \">";
}

?>

